package com.example;
public class Authentication {
    public boolean authenticateUser(String username, String password) {
     
        String validUsername = "Shubhangi";
        String validPassword = "Shubhi124";   
        return username.equals(validUsername) && password.equals(validPassword);
    }
}