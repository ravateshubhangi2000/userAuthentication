package com.example;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class AuthenticationTest {
	 @Test
	    public void testAuthenticateUser_ValidCredentials_ShouldReturnTrue() {
	        // Arrange
	        Authentication authClass = new Authentication();
	        String validUsername = "Shubhangi";
	        String validPassword = "Shubhi124";

	        // Act
	        boolean isAuthenticated = authClass.authenticateUser(validUsername, validPassword);

	        // Assert
	        assertTrue(isAuthenticated);
	    }

	    @Test
	    public void testAuthenticateUser_InvalidCredentials_ShouldReturnFalse() {
	        // Arrange
	        Authentication authClass = new Authentication();
	        String invalidUsername = "invalidUser";
	        String invalidPassword = "invalidPassword";

	        // Act
	        boolean isAuthenticated = authClass.authenticateUser(invalidUsername, invalidPassword);

	        // Assert
	        assertFalse(isAuthenticated);
	    }

}
